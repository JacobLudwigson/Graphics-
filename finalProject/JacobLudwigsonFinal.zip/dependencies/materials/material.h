#include "../headers.h"

extern Material polishedMetal;
extern Material darkMetal;
extern Material matteSurface;
extern Material glossyPlastic;
extern Material brushedMetal;
extern Material glass;
extern Material rubber;
extern Material gold;
extern Material whitePadding;
extern Material fire;
extern Material LightMaterial;