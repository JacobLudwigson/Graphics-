#include "../particles/particle.h"

extern Light l1;
extern dirLight l4;
extern dirLight powerLight1;
extern dirLight powerLight2;
extern dirLight tvScreen;
extern dirLight hallwayLight1;
extern dirLight hallwayLight2;
extern dirLight hallwayLight3;
extern dirLight hallwayLight4;
extern dirLight hallwayLight5;
extern dirLight hallwayLight6;
extern dirLight hallwayLight7;
extern dirLight hallwayLight8;