#include "sphere.h"
#define NUMVERTICESHALFCUBE 72
void setupHalfCube();
void drawHalfCube(GLuint shader,glm::vec3 position, glm::vec3 scalar, float ph, float th, unsigned int texture);